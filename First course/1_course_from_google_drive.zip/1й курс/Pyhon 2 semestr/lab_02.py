from tkinter import *
from tkinter import messagebox
import random

root = Tk()
root.title("dfvdfvdf")
#
def farrukh():
    b = str(a_entry.get())
    b.insert(0,'')
    for i in range(1,len(b)):
    if b[i-1] > b[i]:
        b[0] = b[i]
        j = i - 1
        while b[j] > b[0]:
            b[j+1] = b[j]
            j = j - 1
        b[j+1] = b[0]
     b.delete(




    
#
def C():
    a_entry.delete(0, END)
#   
def Random_List(koeficient):
    # Считаем элементы для списков в случайном
    List = []
    for i in range(koeficient):
        List.append(random.randrange(0, koeficient, 1))
    return List
#
#Создаём массив a[100], a[1000], a[10000]
#массивы по возрастанию
mass_100= list(range(0, 100))
mass_1000= list(range(0, 1000))
mass_10000= list(range(0, 10000))
#массивы по убиванию
mass_100= [x for x in range(99, 0, -1)]
mass_1000= [x for x in range(999, 0, -1)]
mass_10000= [x for x in range(9999, 0, -1)]
#массивы рандомна
mass_random_100 = Random_List(100)
mass_random_1000 = Random_List(1000)
mass_random_10000 = Random_List(10000)
#
a = StringVar()
a_entry = Entry(textvariable=a)
a_entry.grid(row=1, column=1, columnspan=3, sticky='nsew', padx=5, pady=5)
a_label1 = Label(text="Ответ")
a_label1.grid(row=2, column=1, columnspan=1, padx=5, pady=5, sticky="w")
b_label1 = Label(text="SDCSDC")
b_label1.grid(row=4, column=1, columnspan=3, padx=5, pady=5, sticky="w")
#


#кнопка Решить
button1 = Button(text="Решить", command=farrukh)
button1.grid(row=2, column=4, columnspan=1, padx=5, pady=5, sticky="w")

#кнопка Стерать
button2 = Button(text="C", command=C)
button2.grid(row=1, column=4, columnspan=1, padx=5, pady=5, sticky="w")


root.mainloop()






























